package ml.dhoomilsheta.app.config;

public class KafkaConfiguration {
    public static final String SERVERS = "10.1.0.5:9092, 10.1.0.13:9092, 10.1.0.7:9092";
    //public static final String SERVERS = "10.1.0.10, 10.1.0.11, 10.1.0.4, 10.1.0.6";
    public static final String TOPIC = "tweets";
    public static final long SLEEP_TIMER = 1000;
}
