package ml.dhoomilsheta.app.config;

public class TwitterConfiguration {
    public static final String CONSUMER_KEY = "5ssQEnpnCnfZgPk4JLmIjw";
    public static final String CONSUMER_SECRET = "8eMYnMOwZKxW2efJKS8XJmC9TRrE6DNApczLkG3oCks";
    public static final String ACCESS_TOKEN = "70669617-GuW7Cb5PxVV1YanMJ5ScCInZaU7EeQUAckzFsi1OV";
    public static final String TOKEN_SECRET = "j7q8LEkHXc79k43V2Z47Cmjs1ybsK4BPfugqlhwPfcNj9";
    public static final String HASHTAG = "#INDvSA";
}
